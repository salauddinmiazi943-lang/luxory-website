import { Schema, model, models } from "mongoose";
import type { Model, Types } from "mongoose";

export type AccountTransactionType = "sale" | "due_collection" | "expense" | "payment";
export type AccountPaymentMethod = "cash" | "bkash" | "nagad" | "bank" | "other";

export type AccountTransactionRecord = {
  type: AccountTransactionType;
  amount: number;
  paidAmount: number;
  dueAmount: number;
  category?: Types.ObjectId;
  partyId?: Types.ObjectId;
  partyName: string;
  paymentMethod: AccountPaymentMethod;
  note?: string;
  date: Date;
  createdBy: Types.ObjectId;
  createdAt: Date;
};

const accountTransactionSchema = new Schema<AccountTransactionRecord>({
  type: { type: String, enum: ["sale", "due_collection", "expense", "payment"], required: true, index: true, immutable: true },
  amount: { type: Number, required: true, min: 0.01 },
  paidAmount: { type: Number, required: true, min: 0, default: 0 },
  dueAmount: { type: Number, required: true, min: 0, default: 0 },
  category: {
    type: Schema.Types.ObjectId,
    ref: "AccountCategory",
    required: function (this: AccountTransactionRecord) { return this.type === "expense" || this.type === "payment"; },
    immutable: true,
  },
  partyId: { type: Schema.Types.ObjectId, ref: "AccountParty", index: true, immutable: true },
  partyName: { type: String, required: true, trim: true, maxlength: 160, immutable: true },
  paymentMethod: { type: String, enum: ["cash", "bkash", "nagad", "bank", "other"], required: true, default: "other" },
  note: { type: String, trim: true, maxlength: 2000 },
  date: { type: Date, required: true, index: true, immutable: true },
  createdBy: { type: Schema.Types.ObjectId, ref: "User", required: true, immutable: true },
  createdAt: { type: Date, required: true, default: Date.now, immutable: true },
}, { versionKey: false });

accountTransactionSchema.index({ date: -1, type: 1 });
accountTransactionSchema.index({ partyId: 1, date: -1, createdAt: -1 });
accountTransactionSchema.index({ category: 1, date: -1 });

accountTransactionSchema.pre("validate", function () {
  if (this.type === "sale" && Math.abs(this.amount - this.paidAmount - this.dueAmount) > 0.011) {
    this.invalidate("dueAmount", "বিক্রির মোট টাকা = আদায় + বাকি হতে হবে।");
  }
  if (this.type === "due_collection" && this.dueAmount !== 0) {
    this.invalidate("dueAmount", "বাকি আদায়ের এন্ট্রিতে নতুন বাকি থাকা যাবে না।");
  }
});

export const AccountTransaction: Model<AccountTransactionRecord> =
  (models.AccountTransaction as Model<AccountTransactionRecord> | undefined) ??
  model<AccountTransactionRecord>("AccountTransaction", accountTransactionSchema);
